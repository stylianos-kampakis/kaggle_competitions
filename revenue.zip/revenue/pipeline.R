file.path(data_dir, "train.csv")

data_dir="C:/Users/stelios/Dropbox/Freelance/Kaggle/revenue"

source(file.path(data_dir, "prcomp_and_kmeans.R"))
source(file.path(data_dir, "train.R"))
source(file.path(data_dir, "load_pca_and_cluster.R"))
source(file.path(data_dir, "submit.R"))


